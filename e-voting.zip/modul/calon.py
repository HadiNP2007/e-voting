from .data import calon_list
from .utils import cari_calon


def tambah_calon():
    print("\n=== Tambah Calon ===")

    id_calon = input("ID Calon : ")

    if cari_calon(id_calon):
        print("ID sudah digunakan!")
        return

    nama = input("Nama : ")
    visi = input("Visi : ")

    calon = {
        "id": id_calon,
        "nama": nama,
        "visi": visi,
        "jumlah_suara": 0
    }

    calon_list.append(calon)

    print("Calon berhasil ditambahkan.")