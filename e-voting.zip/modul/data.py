pemilih_list = []

calon_list = []