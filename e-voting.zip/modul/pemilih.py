from .data import pemilih_list
from .utils import cari_pemilih


def tambah_pemilih():
    print("\n=== Tambah Pemilih ===")

    id_pemilih = input("ID Pemilih : ")

    if cari_pemilih(id_pemilih):
        print("ID sudah digunakan!")
        return

    nama = input("Nama : ")
    jurusan = input("Jurusan : ")

    pemilih = {
        "id": id_pemilih,
        "nama": nama,
        "jurusan": jurusan,
        "sudah_memilih": False
    }

    pemilih_list.append(pemilih)

    print("Pemilih berhasil ditambahkan.")