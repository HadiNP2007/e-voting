from .data import pemilih_list, calon_list


def tampilkan_statistik():

    print("\n===== STATISTIK PEMILU =====")

    total_pemilih = len(pemilih_list)

    sudah_memilih = 0

    for pemilih in pemilih_list:
        if pemilih["sudah_memilih"]:
            sudah_memilih += 1

    if total_pemilih == 0:
        persentase = 0
    else:
        persentase = (sudah_memilih / total_pemilih) * 100

    print("Total Pemilih :", total_pemilih)
    print("Sudah Memilih :", sudah_memilih)
    print("Belum Memilih :", total_pemilih - sudah_memilih)
    print("Persentase Partisipasi : %.2f%%" % persentase)

    if len(calon_list) == 0:
        print("Belum ada calon.")
        return

    pemenang = calon_list[0]

    for calon in calon_list:
        if calon["jumlah_suara"] > pemenang["jumlah_suara"]:
            pemenang = calon

    print("\nPemenang Sementara")
    print("Nama :", pemenang["nama"])
    print("Jumlah Suara :", pemenang["jumlah_suara"])