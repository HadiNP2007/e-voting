from .data import pemilih_list, calon_list


def cari_pemilih(id_pemilih):
    for pemilih in pemilih_list:
        if pemilih["id"] == id_pemilih:
            return pemilih
    return None


def cari_calon(id_calon):
    for calon in calon_list:
        if calon["id"] == id_calon:
            return calon
    return None