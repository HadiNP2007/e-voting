from .utils import cari_pemilih, cari_calon
from .data import calon_list


def lakukan_voting():
    print("\n=== Voting ===")

    id_pemilih = input("Masukkan ID Pemilih : ")

    pemilih = cari_pemilih(id_pemilih)

    if pemilih is None:
        print("ID pemilih tidak ditemukan.")
        return

    if pemilih["sudah_memilih"]:
        print("Pemilih sudah melakukan voting.")
        return

    print("\nDaftar Calon")

    for calon in calon_list:
        print(f'{calon["id"]} - {calon["nama"]}')

    id_calon = input("Masukkan ID Calon : ")

    calon = cari_calon(id_calon)

    if calon is None:
        print("ID calon tidak ditemukan.")
        return

    calon["jumlah_suara"] += 1
    pemilih["sudah_memilih"] = True

    print("Voting berhasil.")
    

def tampilkan_hasil():

    print("\n===== HASIL SEMENTARA =====")

    if len(calon_list) == 0:
        print("Belum ada calon.")
        return

    for calon in calon_list:

        print("----------------------")
        print("ID :", calon["id"])
        print("Nama :", calon["nama"])
        print("Visi :", calon["visi"])
        print("Suara :", calon["jumlah_suara"])